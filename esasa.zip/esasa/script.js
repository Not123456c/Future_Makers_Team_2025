function startCountdown() {
    const eventDate = new Date("2025-06-15T00:00:00").getTime();
    
    const colors = ["#ff9999", "#66b3ff", "#99ff99", "#ffcc99", "#ffb3e6", "#c2c2f0", "#ff6666", "#c4e17f", "#b3b3b3", "#ffb3b3", "#c4e1ff", "#ffebcc"];
    const monthNames = ["يناير", "فبراير", "مارس", "أبريل", "مايو", "يونيو", "يوليو", "أغسطس", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر"];

    function updateCountdown() {
        const now = new Date().getTime();
        const distance = eventDate - now;
        
        if (distance < 0) {
            document.getElementById('timer').innerHTML = "الحدث قد بدأ!";
            document.getElementById('months').innerHTML = "";
            return;
        }
        
        const days = Math.floor(distance / (1000 * 60 * 60 * 24));
        const hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
        const seconds = Math.floor((distance % (1000 * 60)) / 1000);

        document.getElementById('timer').innerHTML = `${days} أيام ${hours} ساعات ${minutes} دقائق ${seconds} ثوانٍ`;
        
        // حساب الأشهر المتبقية
        const monthsRemaining = Math.ceil(distance / (1000 * 60 * 60 * 24 * 30));
        const monthsDiv = document.getElementById('months');
        monthsDiv.innerHTML = "";
        
        for (let i = 0; i < 12; i++) {
            let monthDiv = document.createElement('div');
            monthDiv.className = 'month';
            monthDiv.style.backgroundColor = colors[i];
            monthDiv.innerHTML = monthNames[i];
            
            if (i < monthsRemaining) {
                monthDiv.classList.add('active');
            }
            
            if (i === new Date().getMonth()) {
                monthDiv.classList.add('current-month');
            }
            
            monthsDiv.appendChild(monthDiv);
        }
    }

    function showWelcomeModal() {
        const modal = document.getElementById('welcome-modal');
        const span = document.querySelector('.close');

        modal.style.display = "block";
        
        span.onclick = function() {
            modal.style.display = "none";
        }

        window.onclick = function(event) {
            if (event.target === modal) {
                modal.style.display = "none";
            }
        }

        // إخفاء النافذة المنبثقة بعد 5 ثوانٍ
        setTimeout(() => {
            modal.style.display = "none";
        }, 5000);
    }

    updateCountdown();
    setInterval(updateCountdown, 1000);
    window.onload = showWelcomeModal;
}

window.onload = startCountdown;
